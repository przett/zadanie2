# Technologie Chmurowe - Zadanie 2.

## Dokumentacja

![Schemat architektury](./arch.png)

