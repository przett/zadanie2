# README_dev - wersja rozwojowa

## Użyta komenda

docker compose -f docker-ompose.dev.yml up -d

## Screen

![Screeny działania usługi](./Docs/Readme_dev.png)(./Docs/Readme_dev1.png)


