# README - wersja produkcyjna

## Uruchomienie usługi

Aby uruchomić usługę w wersji produkcyjnej:

docker compose up

## Dowód działania usługi

![Screeny działania usługi](./Docs/Readme_prod.png)(./Docs/Readme_prod1.png)


